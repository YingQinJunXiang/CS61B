#pragma once

struct list_node {
	int               value;
	struct list_node *next;
};
