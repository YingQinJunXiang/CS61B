#pragma once

struct point {
	double x;
	double y;
};
