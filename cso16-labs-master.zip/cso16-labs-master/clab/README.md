Lab1: C Exercises (due: 9/28)
