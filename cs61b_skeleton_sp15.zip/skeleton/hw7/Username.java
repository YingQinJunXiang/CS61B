public class Username {

    // Potentially useless note: (int) '0' == 48, (int) 'a' == 97

    // Instance Variables (remember, they should be private!)
    // YOUR CODE HERE

    public Username() {
        // YOUR CODE HERE
    }

    public Username(String reqName) {
        // YOUR CODE HERE
    }

    @Override
    public boolean equals(Object o) {
        // YOUR CODE HERE
        return false;
    }

    @Override
    public int hashCode() { 
        // YOUR CODE HERE
        return 0;
    }

    public static void main(String[] args) {
        // You can put some simple testing here.
    }
}