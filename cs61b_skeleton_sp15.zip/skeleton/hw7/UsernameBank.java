import java.util.Map;

public class UsernameBank {

    // Instance variables (remember, they should be private!)
    // YOUR CODE HERE

    public UsernameBank() {
        // YOUR CODE HERE
    }

    public void generateUsername(String username, String email) {
        // YOUR CODE HERE
    }

    public String getEmail(String username) {
        // YOUR CODE HERE
        return null;
    }

    public String getUsername(String userEmail)  {
        // YOUR CODE HERE
        return null;
    }

    public Map<String, Integer> getBadEmails() {
        // YOUR CODE HERE
        return null;
    }

    public Map<String, Integer> getBadUsernames() {
        // YOUR CODE HERE
        return null;
    }

    public String suggestUsername() {
        // YOUR CODE HERE
        return null;
    }

    // The answer is somewhere in between 3 and 1000.
    public static final int followUp() {
        // YOUR CODE HERE
        return 0;
    }

    // Optional, suggested method. Use or delete as you prefer.
    private void recordBadUsername(String username) {
        // YOUR CODE HERE
    }

    // Optional, suggested method. Use or delete as you prefer.
    private void recordBadEmail(String email) {
        // YOUR CODE HERE
    }
}