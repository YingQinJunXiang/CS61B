XChartDemo.java and ExampleUI.java should compile and run, even if you haven't done any of the project.

The remaining java files will only compile after you have completed the relevant class from the assignment. These demo files are provided as examples so that you can get a deeper understanding of what your classes are supposed to do.
