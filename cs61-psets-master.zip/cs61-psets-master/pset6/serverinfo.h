#ifndef CS61_SERVERINFO_H
#define CS61_SERVERINFO_H 1

#ifndef PONG_HOST
# define PONG_HOST "cs61.seas.harvard.edu"
#endif

#ifndef PONG_PORT
# define PONG_PORT "6168"
#endif

#ifndef PONG_USER
# define PONG_USER "test"
#endif

#endif
